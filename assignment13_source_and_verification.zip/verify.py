#!/usr/bin/env python3
"""Exact finite certificates for the four specified pure Type II ray minima.

Python 3.8+; standard library only. Run:
    python3 verify.py --output-dir rerun

The exhaustive lower-modulus checks use the manuscript's proved NECESSARY
conditions -1 not in H and |G/H| >= 8. They do not prove that theorem.
Quotient certificates exhaust their stated finite boxes. Point examples are
finite checks, not proofs of infinitely many prime values or of all m.
No search for new families is performed. No floating-point arithmetic is used.
"""

import argparse
from collections import Counter
from fractions import Fraction
from itertools import product
import json
from math import gcd, isqrt
from pathlib import Path


def require(condition, message):
    """Checks remain active even when Python is invoked with -O."""
    if not condition:
        raise AssertionError(message)


def factor(n):
    require(n >= 1, "factor expects a positive integer")
    factors = []
    d = 2
    while d * d <= n:
        if n % d == 0:
            exponent = 0
            while n % d == 0:
                n //= d
                exponent += 1
            factors.append([d, exponent])
        d = 3 if d == 2 else d + 2
    if n > 1:
        factors.append([n, 1])
    return factors


def prime_certificate(n):
    """Complete deterministic trial division; composites include a factor."""
    if n < 2:
        return {"n": n, "is_prime": False, "reason": "n < 2"}
    if n == 2:
        return {"n": n, "is_prime": True, "trial_bound": 1}
    bound = isqrt(n)
    if n % 2 == 0:
        return {"n": n, "is_prime": False, "factor": 2, "cofactor": n // 2}
    for d in range(3, bound + 1, 2):
        if n % d == 0:
            return {"n": n, "is_prime": False, "factor": d, "cofactor": n // d}
    return {"n": n, "is_prime": True, "trial_bound": bound,
            "method": "2 and every odd integer through floor(sqrt(n))"}


def units(a):
    return [g for g in range(1, a) if gcd(g, a) == 1]


def totient_by_factorization(a):
    result = a
    for p, _ in factor(a):
        result = result // p * (p - 1)
    return result


def cyclic_subgroup(g, a):
    require(gcd(g, a) == 1, "generator must be a unit")
    result = []
    t = 1
    while t not in result:
        result.append(t)
        t = t * g % a
    require(t == 1, "a unit power orbit must close at 1")
    return tuple(sorted(result))


def cyclic_subgroup_certificate(a, generator):
    group = units(a)
    H = cyclic_subgroup(generator, a)
    require(len(group) == totient_by_factorization(a), "totient cross-check")
    require(len(group) % len(H) == 0, "Lagrange divisibility")
    index = len(group) // len(H)
    minus_one_in_H = a - 1 in H
    return {"a": a, "generator_residue": generator % a,
            "phi": len(group), "order": len(H), "H": list(H),
            "index": index, "minus_one_in_H": minus_one_in_H,
            "excluded_by_sign_or_index": minus_one_in_H or index < 8}


def all_cyclic_subgroups(a):
    by_H = {}
    for g in units(a):
        H = cyclic_subgroup(g, a)
        by_H.setdefault(H, []).append(g)
    rows = []
    for H, generators in sorted(by_H.items(), key=lambda pair: (len(pair[0]), pair[0])):
        row = cyclic_subgroup_certificate(a, generators[0])
        row["all_generator_residues"] = generators
        rows.append(row)
    require(sorted(g for row in rows for g in row["all_generator_residues"])
            == units(a), "every unit generator occurs exactly once")
    return {"a": a, "phi": len(units(a)), "units": units(a),
            "distinct_cyclic_subgroups": rows}


def modulus_certificates():
    below_11 = [all_cyclic_subgroups(a) for a in range(3, 11, 4)]
    require([row["a"] for row in below_11] == [3, 7], "domain below 11")
    for row in below_11:
        require(all(H["excluded_by_sign_or_index"] for H in row["distinct_cyclic_subgroups"]),
                "all subgroups below 11 must be excluded")

    below_31 = [all_cyclic_subgroups(a) for a in range(3, 31, 4)]
    require([row["a"] for row in below_31] == [3, 7, 11, 15, 19, 23, 27], "domain below 31")
    for row in below_31:
        nontrivial = [H for H in row["distinct_cyclic_subgroups"] if H["order"] > 1]
        require(all(H["excluded_by_sign_or_index"] for H in nontrivial),
                "all NONTRIVIAL subgroups below 31 must be excluded")

    below_127 = [cyclic_subgroup_certificate(a, 2) for a in range(3, 127, 4)]
    require(len(below_127) == 31, "exactly 31 moduli below 127")
    require(all(row["excluded_by_sign_or_index"] for row in below_127), "base-2 exclusion")
    require(all(row["index"] <= 6 for row in below_127), "stronger index-only certificate")

    all_below_195 = [{"a": a, "primality": prime_certificate(a)} for a in range(3, 195, 4)]
    below_195 = [cyclic_subgroup_certificate(row["a"], 2) for row in all_below_195
                 if not row["primality"]["is_prime"]]
    expected_composites = [15, 27, 35, 39, 51, 55, 63, 75, 87, 91, 95, 99,
                           111, 115, 119, 123, 135, 143, 147, 155, 159, 171,
                           175, 183, 187]
    require([row["a"] for row in below_195] == expected_composites, "exact 25 composite domain")
    require(all(row["index"] in (1, 2, 4, 6) for row in below_195), "composite index certificate")

    at_11 = all_cyclic_subgroups(11)
    survivors_11 = [H for H in at_11["distinct_cyclic_subgroups"] if not H["excluded_by_sign_or_index"]]
    require([H["H"] for H in survivors_11] == [[1]], "forced H at 11")
    at_31 = all_cyclic_subgroups(31)
    survivors_31 = [H for H in at_31["distinct_cyclic_subgroups"]
                    if H["order"] > 1 and not H["excluded_by_sign_or_index"]]
    require([H["H"] for H in survivors_31] == [[1, 5, 25]], "forced nontrivial H at 31")
    return {
        "scope": "Modulus minima conditional on the proved necessary sign/index theorem; no prime-product minimum claim.",
        "all_cyclic_H_below_11": below_11,
        "all_cyclic_H_below_31_nontrivial_H_only_for_exclusion": below_31,
        "all_31_base2_moduli_below_127": below_127,
        "all_48_eligible_moduli_below_195_with_primality": all_below_195,
        "all_25_composite_base2_moduli_below_195": below_195,
        "all_cyclic_H_at_11": at_11,
        "all_cyclic_H_at_31": at_31,
        "surviving_H_at_11": survivors_11,
        "surviving_nontrivial_H_at_31": survivors_31,
        "counts": {"below_11": len(below_11), "below_31": len(below_31),
                   "base2_below_127": len(below_127), "eligible_below_195": len(all_below_195),
                   "composite_base2_below_195": len(below_195)},
    }


class Quotient:
    """Actual cosets, represented by their least integer member."""
    def __init__(self, a, g):
        self.a = a
        self.G = units(a)
        self.H = cyclic_subgroup(g, a)
        self.coset_of = {}
        self.cosets = {}
        for t in self.G:
            C = tuple(sorted(t * h % a for h in self.H))
            representative = C[0]
            self.coset_of[t] = representative
            self.cosets[representative] = C
        self.representatives = sorted(self.cosets)
        require(len(self.representatives) * len(self.H) == len(self.G), "coset partition size")
        require(sorted(t for C in self.cosets.values() for t in C) == self.G, "coset partition")
        self.N = self.rep(-1)
        self.T = self.rep(-pow(4, -1, a))

    def rep(self, t):
        return self.coset_of[t % self.a]

    def order(self, t):
        for k in range(1, len(self.representatives) + 1):
            if self.rep(pow(t, k, self.a)) == self.rep(1):
                return k
        raise AssertionError("quotient order was not found")

    def box(self, q2, q3, r, s):
        return sorted({self.rep(pow(q2, i, self.a) * pow(q3, j, self.a))
                       for i in range(r + 1) for j in range(s + 1)})

    def certificate(self):
        orders = {str(t): self.order(t) for t in self.representatives}
        return {"a": self.a, "H": list(self.H), "index": len(self.representatives),
                "cosets": {str(t): list(self.cosets[t]) for t in self.representatives},
                "N_representative": self.N, "T_representative": self.T,
                "orders": orders,
                "order_histogram": dict(sorted(Counter(orders.values()).items())),
                "square_cosets": sorted({self.rep(t * t) for t in self.representatives})}


FAMILIES = (
    {"name": "a11", "a": 11, "q1": 23, "q2": 7, "q3": 37,
     "r": 1, "s": 1, "delta": 0, "u": 1, "v": 1, "m0": 1, "point_range": [1, 4]},
    {"name": "a31", "a": 31, "q1": 5, "q2": 7, "q3": 11,
     "r": 1, "s": 1, "delta": -1, "u": 1, "v": 1, "m0": 1, "point_range": [1, 6]},
    {"name": "a127", "a": 127, "q1": 2, "q2": 3, "q3": 11,
     "r": 1, "s": 2, "delta": 1, "u": 1, "v": 2, "m0": 1, "point_range": [1, 6]},
    {"name": "a195", "a": 195, "q1": 2, "q2": 11, "q3": 19,
     "r": 1, "s": 1, "delta": 4, "u": 1, "v": 1, "m0": 4, "point_range": [1, 8]},
)


def quotient_certificate(f):
    a, q1, q2, q3, r, s = (f[key] for key in ("a", "q1", "q2", "q3", "r", "s"))
    require(a % 4 == 3, "eligible modulus")
    require(len({q1, q2, q3}) == 3, "three distinct prime bases")
    require(all(prime_certificate(q)["is_prime"] for q in (q1, q2, q3)), "prime bases")
    require(all(gcd(q, a) == 1 for q in (q1, q2, q3)), "unit bases")
    Q = Quotient(a, q1)
    ordinary = Q.box(q2, q3, r, s)
    quadratic = Q.box(q2, q3, 2 * r, 2 * s)
    saddles = []
    for u in range(1, r + 1):
        for v in range(1, s + 1):
            if Q.rep(pow(q2, u, a)) == Q.rep(-pow(q3, v, a)):
                shifts = [delta for delta in range(-len(Q.H), len(Q.H) + 1)
                          if (pow(q1, delta, a) * pow(q2, u, a) + pow(q3, v, a)) % a == 0]
                minimum = min(abs(delta) for delta in shifts)
                saddles.append({"u": u, "v": v, "least_absolute_shift": minimum,
                                "all_minimizing_signed_shifts": [delta for delta in shifts if abs(delta) == minimum]})
    conditions = {"ordinary_sign_avoidance": Q.N not in ordinary,
                  "mixed_sign_saddle_exists": bool(saddles),
                  "quadratic_TypeI_avoidance": Q.T not in quadratic}
    require(all(conditions.values()), "all three pure-ray quotient conditions")
    require(Q.N != Q.rep(1), "nontrivial sign coset")
    require(len(Q.representatives) >= 8, "index necessary condition")
    require((pow(q1, f["delta"], a) * pow(q2, f["u"], a) + pow(q3, f["v"], a)) % a == 0,
            "specified lifted saddle")
    min_shift = min(row["least_absolute_shift"] for row in saddles)
    canonical_start = 1
    while 2 * q1 ** canonical_start * q2 ** r * q3 ** s < a + 1:
        canonical_start += 1
    require(max(1, min_shift, canonical_start) == f["m0"], "stated start from all saddle lifts")
    return {"parameters": f, "quotient": Q.certificate(),
            "ordinary_coset_box": ordinary, "quadratic_coset_box": quadratic,
            "omitted_quadratic_cosets": sorted(set(Q.representatives) - set(quadratic)),
            "conditions": conditions, "all_saddles_in_fixed_box": saddles,
            "canonical_start": canonical_start, "least_absolute_saddle_shift": min_shift}


def divisors_from_prime_exponents(primes, exponents):
    return sorted({p0 ** i * p1 ** j * p2 ** k
                   for (p0, p1, p2) in [primes]
                   for i, j, k in product(*(range(e + 1) for e in exponents))})


EXPECTED_EXAMPLES = {
    ("a31", 2): {"p": 7669, "x": 1925, "e": 245, "d": 15125, "y": 4217950, "z": 536830},
    ("a127", 1): {"p": 2777, "x": 726, "e": 36, "d": 14641, "y": 336017, "z": 16662},
    ("a127", 3): {"p": 11489, "x": 2904, "e": 144, "d": 58564, "y": 5560676, "z": 275736},
    ("a127", 5): {"p": 46337, "x": 11616, "y": 89708432, "z": 4448352},
    ("a127", 6): {"p": 92801, "x": 23232, "y": 359325472, "z": 17817792},
    ("a195", 5): {"p": 26557, "x": 6688, "e": 61952, "d": 722, "y": 1009166, "z": 9348064},
    ("a195", 6): {"p": 53309, "x": 13376, "e": 123904, "d": 1444, "y": 4051484, "z": 37529536},
    # Independent arithmetic corrects the active ledger's y=64998584 here.
    ("a195", 8): {"p": 213821, "x": 53504, "e": 495616, "d": 5776, "y": 65001584, "z": 602119936},
}


def explicit_denominators(name, m, p):
    if name == "a11":
        return 148 * 23 ** m * p, 28 * 23 ** m * p
    if name == "a31":
        return 22 * 5 ** m * p, 14 * 5 ** (m - 1) * p
    if name == "a127":
        return 121 * 2 ** (m - 1) * p, 3 * 2 ** m * p
    if name == "a195":
        return 19 * 2 ** (m - 4) * p, 11 * 2 ** m * p
    raise AssertionError("unknown family")


def point_certificate(f, m):
    a, q1, q2, q3, r, s = (f[key] for key in ("a", "q1", "q2", "q3", "r", "s"))
    x = q1 ** m * q2 ** r * q3 ** s
    p = 4 * x - a
    ordinary = divisors_from_prime_exponents((q1, q2, q3), (m, r, s))
    quadratic = divisors_from_prime_exponents((q1, q2, q3), (2 * m, 2 * r, 2 * s))
    require(len(ordinary) == (m + 1) * (r + 1) * (s + 1), "all divisors of x")
    require(len(quadratic) == (2 * m + 1) * (2 * r + 1) * (2 * s + 1), "all divisors of x squared")
    ordinary_I = [g for g in ordinary if (4 * g + 1) % a == 0]
    ordinary_II = [g for g in ordinary if (g + x) % a == 0]
    quadratic_I = [g for g in quadratic if (4 * g + 1) % a == 0]
    quadratic_II = [g for g in quadratic if (g + x) % a == 0]
    is_rescue = bool(quadratic_II) and not ordinary_I and not ordinary_II and not quadratic_I
    row = {"m": m, "x": x, "p": p, "primality": prime_certificate(p),
           "canonical": 2 * x >= a + 1,
           "ordinary_divisor_count": len(ordinary), "quadratic_divisor_count": len(quadratic),
           "ordinary_divisor_residues": sorted({g % a for g in ordinary}),
           "quadratic_divisor_residues": sorted({g % a for g in quadratic}),
           "ordinary_TypeI_hits": ordinary_I, "ordinary_TypeII_hits": ordinary_II,
           "quadratic_TypeI_hits": quadratic_I, "quadratic_TypeII_hits": quadratic_II,
           "pure_modular_TypeII_rescue": bool(is_rescue)}
    require(not ordinary_I and not ordinary_II and not quadratic_I, "point avoids all forbidden targets")
    if m < f["m0"]:
        require(not is_rescue, "prethreshold point has no rescue")
        return row
    require(is_rescue and p > 0 and row["canonical"], "valid canonical modular rescue")
    delta, u, v = f["delta"], f["u"], f["v"]
    require(m + delta >= 0 and m - delta >= 0, "nonnegative witness exponents")
    e = q1 ** (m + delta) * q2 ** (r + u) * q3 ** (s - v)
    d = q1 ** (m - delta) * q2 ** (r - u) * q3 ** (s + v)
    require(e * d == x * x, "complementary divisors")
    require(e in quadratic_II and d in quadratic_II, "both Type II witnesses")
    require(x % e != 0 and x % d != 0, "strictly quadratic witnesses")
    require((x + d) % a == 0 and (x + e) % a == 0, "integral denominator factors")
    y = p * ((x + d) // a)
    z = p * ((x + e) // a)
    require((y, z) == explicit_denominators(f["name"], m, p), "published denominator formula")
    lhs = 4 * x * y * z
    rhs = p * (y * z + x * z + x * y)
    require(lhs == rhs, "original 4/p equation by integer cross-multiplication")
    require(y % p == 0 and z % p == 0 and gcd(x, p) == 1, "Type II divisibility pattern")
    row.update({"e": e, "d": d, "y": y, "z": z,
                "cross_multiplication_lhs": lhs, "cross_multiplication_rhs": rhs,
                "cross_multiplication_equal": lhs == rhs})
    if (f["name"], m) == ("a195", 8):
        wrong_y = 64998584
        wrong_residual = 4 * x * wrong_y * z - p * (wrong_y * z + x * z + x * wrong_y)
        require(wrong_residual != 0, "ledger literal must fail original equation")
        row["active_ledger_discrepancy"] = {
            "reference": "A12G0788, Section 3.7 reconciliation bullet for m=8",
            "quantity": "y", "stated": wrong_y, "correct": y,
            "integer_cross_multiplication_residual_using_stated_y": wrong_residual,
            "stated_y_mod_p": wrong_y % p,
        }
    for key, expected in EXPECTED_EXAMPLES.get((f["name"], m), {}).items():
        require(row[key] == expected, "corrected ledger example: %s m=%s %s" % (f["name"], m, key))
    return row


def rational_coefficient_certificate(f):
    """Check the four ALREADY STATED formulas as rational coefficient identities."""
    a, q1, q2, q3, r, s, delta, u, v = (f[key] for key in
        ("a", "q1", "q2", "q3", "r", "s", "delta", "u", "v"))
    X = Fraction(q2 ** r * q3 ** s)
    E = Fraction(q1) ** delta * q2 ** (r + u) * q3 ** (s - v)
    D = Fraction(q1) ** (-delta) * q2 ** (r - u) * q3 ** (s + v)
    Y, Z = (X + D) / a, (X + E) / a
    require(E * D == X * X, "rational coefficient complementarity")
    require((Y + Z) * X == a * Y * Z, "rational coefficient unit-fraction identity")
    return {"interpretation": "x=X*q1^m, e=E*q1^m, d=D*q1^m, y=Y*q1^m*p, z=Z*q1^m*p",
            "coefficients": {key: str(value) for key, value in zip(("X", "E", "D", "Y", "Z"), (X, E, D, Y, Z))},
            "ED_equals_X_squared": True, "X_times_Y_plus_Z_equals_aYZ": True,
            "limitation": "Coefficient identities alone do not prove avoidance, integrality at every m, or primality."}


def structure_195():
    Q = Quotient(195, 2)
    def dlog2(g, modulus):
        for exponent in range(modulus):
            if pow(2, exponent, modulus) == g % modulus:
                return exponent
        raise AssertionError("missing CRT discrete logarithm")
    def psi(g):
        alpha, beta, gamma = (dlog2(g, modulus) for modulus in (3, 5, 13))
        return ((alpha - gamma) % 2, (beta - gamma) % 4)
    expected_image = set(product(range(2), range(4)))
    require({psi(g) for g in Q.G} == expected_image, "surjective CRT quotient map")
    require([g for g in Q.G if psi(g) == (0, 0)] == list(Q.H), "CRT map kernel exactly H")
    for g, h in product(Q.G, repeat=2):
        require(psi(g * h % 195) == tuple((x + y) % modulus for x, y, modulus in zip(psi(g), psi(h), (2, 4))),
                "CRT quotient homomorphism for every pair")
    require(psi(-1) == (1, 0) and psi(11) == (0, 1) and psi(19) == (1, 1), "specified CRT images")
    require(Q.N not in {Q.rep(g * g) for g in Q.G}, "N is not a square in Q")
    require(Q.order(11) == 4 and Q.order(19) == 4, "order-four fixed cosets")
    require(Q.box(11, 19, 2, 2) == sorted(set(Q.representatives) - {Q.N}), "sharp seven-coset footprint")
    return {"isomorphism": "Q -> C2 x C4, g -> (alpha-gamma mod2, beta-gamma mod4)",
            "local_log_bases": {"3": 2, "5": 2, "13": 2},
            "coset_images": {str(g): list(psi(g)) for g in Q.representatives},
            "homomorphism_pairs_checked": len(Q.G) ** 2, "kernel_equals_H": True,
            "N_image": list(psi(-1)), "q2_image": list(psi(11)), "q3_image": list(psi(19)),
            "N_not_square": True, "quadratic_box_equals_Q_minus_N": True}


def structure_127():
    Q = Quotient(127, 2)
    require(len(Q.representatives) == 18 and Q.order(3) == 18, "cyclic quotient generated by 3H")
    exponent_by_rep = {Q.rep(pow(3, k, 127)): k for k in range(18)}
    omitted = sorted(exponent_by_rep[t] for t in set(Q.representatives) - set(Q.box(3, 11, 2, 4)))
    require(exponent_by_rep[Q.rep(11)] == 14 and exponent_by_rep[Q.N] == 9, "stated quotient logs")
    require(omitted == [5, 9, 13, 17], "14-of-18 footprint, not 15 distinct cosets")
    return {"quotient_cyclic_order": 18, "generator_coset": "3H",
            "coset_discrete_logs": {str(t): exponent_by_rep[t] for t in Q.representatives},
            "N_log": 9, "T_log": exponent_by_rep[Q.T], "q3_log": 14,
            "omitted_quadratic_coset_logs": omitted, "quadratic_box_size": 14}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent / "rerun")
    args = parser.parse_args()
    minima = modulus_certificates()
    families = {}
    for f in FAMILIES:
        start, stop = f["point_range"]
        points = [point_certificate(f, m) for m in range(start, stop + 1)]
        prime_ms = [row["m"] for row in points if row["primality"]["is_prime"] and row["pure_modular_TypeII_rescue"]]
        families[f["name"]] = {"quotient_certificate": quotient_certificate(f),
                                "coefficient_identity": rational_coefficient_certificate(f),
                                "point_checks": points, "prime_rescue_exponents_in_checked_range": prime_ms}
    require(families["a11"]["prime_rescue_exponents_in_checked_range"] == [], "a11 finite primality catalog")
    require(families["a31"]["prime_rescue_exponents_in_checked_range"] == [2], "a31 finite primality catalog")
    require(families["a127"]["prime_rescue_exponents_in_checked_range"] == [1, 3, 5, 6], "a127 finite primality catalog")
    require(families["a195"]["prime_rescue_exponents_in_checked_range"] == [5, 6, 8], "a195 finite primality catalog")
    families["a127"]["additional_quotient_structure"] = structure_127()
    families["a195"]["additional_quotient_structure"] = structure_195()
    summary = {"status": "ALL CHECKS PASSED", "arithmetic": "exact integers and Fraction; deterministic trial division",
               "modulus_domains": minima["counts"],
               "minimum_moduli": {"unrestricted_pure_eventual_3D_ray": 11,
                                  "nontrivial_cyclic_growing_subgroup": 31,
                                  "growing_base_2": 127, "growing_base_2_composite_modulus": 195},
               "minimum_moduli_dependency": "The necessary sign/index theorem is proved in the manuscript; finite arithmetic here plus the exhibited witnesses certifies its applications.",
               "families": {name: {"point_range": data["quotient_certificate"]["parameters"]["point_range"],
                                    "prime_rescue_exponents": data["prime_rescue_exponents_in_checked_range"],
                                    "quotient_conditions": data["quotient_certificate"]["conditions"]}
                            for name, data in families.items()},
               "not_claimed": ["infinitely many prime p", "prime-product tie-breaker minima", "novelty",
                               "all-m validity inferred solely from a finite list of m"],
               "source_discrepancies": [row["active_ledger_discrepancy"]
                                        for data in families.values() for row in data["point_checks"]
                                        if "active_ledger_discrepancy" in row]}
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for filename, data in (("modulus_certificates.json", minima), ("family_certificates.json", families), ("summary.json", summary)):
        (args.output_dir / filename).write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
