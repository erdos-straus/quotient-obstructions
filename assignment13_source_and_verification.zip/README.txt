ASSIGNMENT 13: RESEARCH NOTE AND REPRODUCIBILITY PACKAGE
Prepared 2 November 2026 for informal expert review.

CONTENTS
assignment13_research_note.pdf: self-contained five-page manuscript.
assignment13_referee_cover_memo.pdf: one-page editorial memo.
assignment13_verification_appendix.pdf: four-page arithmetic appendix.
sources/: standalone LaTeX sources for all three documents.
verify.py: exact-arithmetic verifier; Python 3.8+ standard library only.
printed_certificate.py: the short certificate printed in the manuscript.
certificates/: deterministic JSON data produced by verify.py.
manifest.json: source provenance, QA record, and SHA-256 payload hashes.

REPRODUCE THE ARITHMETIC
From this extracted directory, run:
    python3 verify.py --output-dir rerun
    python3 printed_certificate.py
    diff -ru certificates rerun
The verifier prints a summary ending with status ALL CHECKS PASSED.
The short certificate exits successfully without output; run it without -O.
The diff command should print nothing and return exit status zero.
The larger verifier's checks remain active under Python optimization.
No network connection, mathematical library, or floating-point arithmetic
is required. Fraction objects are exact rational numbers.

REBUILD THE PDFs
Using Tectonic, from the sources directory:
    tectonic assignment13_research_note.tex
    tectonic assignment13_referee_cover_memo.tex
    tectonic assignment13_verification_appendix.tex
The sources also use standard LaTeX packages and may be compiled twice
with pdflatex. First use of Tectonic may download its TeX support files.
Bibliographies are embedded; no BibTeX or external figures are required.
Compiled PDF binary hashes may differ because of creation timestamps.

LOGICAL DOMAINS
The note proves the eventual quotient criterion, index at least eight,
and the base-2 index-eight equality classification. Code does not prove
those universal assertions by sampling.
The minima 11 and 31 have analytic lower-bound proofs, with redundant
checks of all cyclic subgroups for their complete smaller-modulus sets.
The base-2 minimum 127 checks all 31 eligible moduli a=3,7,...,123.
The composite base-2 minimum 195 checks all 25 composites among the
48 eligible moduli a=3,7,...,191. The quotient index is at most six
in each checked case. The proved obstruction excludes all remaining
prime-base and exponent choices there; no prime or exponent cap is used.
Explicit quotient witnesses attain all four stated bounds.

The finite samples m=1..4 (a=11), 1..6 (a=31,127), and 1..8 (a=195)
are illustrative point checks, not arguments for infinitely many prime
inputs. The modular infinitude follows from the manuscript proofs.
No prime-product minima, four-dimensional results, or global absence
of Type I solutions at other denominators are claimed.

SOURCE CORRECTION AND EDITORIAL STATUS
The active ledger's m=8 modulus-195 example has a remaining numerical
typo: y must be 65,001,584, not 64,998,584. The appendix and JSON record
the exact correction and cross-multiplication residual. The original
ledger was not edited. Historical and withdrawn statements are not used
as mathematical support.
Mathematical novelty and significance remain unconfirmed. The sharp
obstruction and precisely constrained minima are submitted as questions
for professional assessment, not as established publication priority.

Editorial verdict: Ready for informal expert review.
