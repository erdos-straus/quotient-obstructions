from math import gcd, isqrt
def prime(n):
    return n >= 2 and all(n % d for d in range(2,isqrt(n)+1))
def index(a):
    h, t = {1}, 2 % a
    while t != 1: h.add(t); t = 2*t % a
    return sum(gcd(t,a)==1 for t in range(1,a)) // len(h)
small = list(range(3,127,4))
comp = [a for a in range(3,195,4) if not prime(a)]
assert len(small)==31 and len(comp)==25
assert all(index(a)<=6 for a in small+comp)
